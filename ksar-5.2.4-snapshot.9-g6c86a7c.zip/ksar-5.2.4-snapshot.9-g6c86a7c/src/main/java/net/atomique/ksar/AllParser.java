/*
 * Copyright 2018 The kSAR Project. All rights reserved.
 * See the LICENSE file in the project root for more information.
 */

package net.atomique.ksar;

import net.atomique.ksar.xml.OSConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public abstract class AllParser {

  private static final Logger log = LoggerFactory.getLogger(AllParser.class);
  private static final Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {
    {
      put("^\\d{8}$", "yyyyMMdd");
      put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
      put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
      put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
      put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
      put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
      put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
      put("^\\d{1,2}-\\d{1,2}-\\d{2}$", "dd-MM-yy");
      put("^\\d{1,2}/\\d{1,2}/\\d{2}$", "MM/dd/yy");
    }
  };

  public AllParser() {

  }

  public void init(kSar hissar, String header) {
    String parserName = header.split("\\s+", 2)[0];
    mysar = hissar;
    ParserName = parserName;
    parse_header(header);
  }

  public AllParser(kSar hissar, String header) {
    init(hissar, header);
  }

  public int parse(String line, String[] columns) {
    log.error("not implemented");
    return -1;
  }

  /**
   * Set {@link #startOfGraph} and {@link #endOfGraph} to the given value if none are available yet
   * or update either of both, depending on if the given value is earlier/later than the formerly
   * stored corresponding one.
   *
   * @param nowStat Date/time of the currently parsed line.
   */
  protected void setStartAndEndOfGraph(LocalDateTime nowStat) {
    if (startOfGraph == null) {
      startOfGraph = nowStat;
    }
    if (endOfGraph == null) {
      endOfGraph = nowStat;
    }

    if (nowStat.compareTo(startOfGraph) < 0) {
      startOfGraph = nowStat;
    }
    if (nowStat.compareTo(endOfGraph) > 0) {
      endOfGraph = nowStat;
    }
  }

  public LocalDateTime getStartOfGraph() {
    return startOfGraph;
  }

  public LocalDateTime getEndOfGraph() {
    return endOfGraph;
  }

  public String getParserName() {
    return ParserName;
  }

  public boolean setDate(String s) {
    LocalDate currentDate;
    LocalDate startDate;
    LocalDate endDate;

    if (sarStartDate == null) {
      sarStartDate = s;
    }
    if (sarEndDate == null) {
      sarEndDate = s;
    }

    try {
      DateTimeFormatter formatter;
      if ("Automatic Detection".equals(dateFormat)) {
        formatter = DateTimeFormatter.ofPattern(determineDateFormat(s));

      } else {
        formatter = DateTimeFormatter.ofPattern(dateFormat);
      }

      log.debug("Date formatter: {}",formatter);
      currentDate = LocalDate.parse(s, formatter);

      startDate = LocalDate.parse(sarStartDate, formatter);
      endDate = LocalDate.parse(sarEndDate, formatter);

    } catch (DateTimeParseException ex) {
      log.error("unable to parse date {}", s, ex);
      return false;
    }

    parsedate = currentDate;

    if (currentDate.compareTo(startDate) < 0) {
      sarStartDate = s;
    }
    if (currentDate.compareTo(endDate) > 0) {
      sarEndDate = s;
    }
    log.debug("parsedDate: {}, startDate: {}, EndDate: {}",currentDate, sarStartDate, sarEndDate);
    return true;
  }

  public String getDate() {
    if (sarStartDate.equals(sarEndDate)) {
      return sarStartDate;
    } else {
      return sarStartDate + " to " + sarEndDate;
    }
  }

  public TreeSet<LocalDateTime> getDateSamples() {
    return DateSamples;
  }

  public String getCurrentStat() {
    return currentStat;
  }

  public static String determineDateFormat(String dateString) {
    for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
      if (dateString.toLowerCase().matches(regexp)) {
        return DATE_FORMAT_REGEXPS.get(regexp);
      }
    }
    return null; // Unknown format.
  }

  protected String sarStartDate = null;
  protected String sarEndDate = null;

  private LocalDateTime startOfGraph = null;
  private LocalDateTime endOfGraph = null;

  protected TreeSet<LocalDateTime> DateSamples = new TreeSet<LocalDateTime>();
  protected int firstdatacolumn = 0;

  abstract public String getInfo();

  abstract public void parse_header(String s);

  abstract public void updateUITitle();

  protected kSar mysar = null;
  protected OSConfig myosconfig = null;
  protected String ParserName = null;

  protected LocalTime parsetime = null;
  protected LocalDate parsedate = null;

  protected String currentStat = "NONE";
  protected String dateFormat = "MM/dd/yy";
  protected String timeFormat = "HH:mm:ss";
  protected int timeColumn = 1;
}
